<?php

return [
    Acme\Api\AcmeApiModule::class,
    Acme\Web\AcmeWebModule::class,
    Shop\User\ShopUserModule::class,
    Shop\Product\ShopProductModule::class,
];
