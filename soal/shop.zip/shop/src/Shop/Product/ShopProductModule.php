<?php
declare(strict_types=1);

namespace Shop\Product;

use Pandawa\Component\Module\AbstractModule;

/**
 * @author  Iqbal Maulana <iq.bluejack@gmail.com>
 */
final class ShopProductModule extends AbstractModule
{
}
