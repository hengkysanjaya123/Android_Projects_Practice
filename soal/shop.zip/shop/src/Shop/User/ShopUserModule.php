<?php
declare(strict_types=1);

namespace Shop\User;

use Pandawa\Component\Module\AbstractModule;

/**
 * @author  Iqbal Maulana <iq.bluejack@gmail.com>
 */
final class ShopUserModule extends AbstractModule
{
}
