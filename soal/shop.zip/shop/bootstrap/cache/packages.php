<?php return array (
  'barryvdh/laravel-ide-helper' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\LaravelIdeHelper\\IdeHelperServiceProvider',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'pandawa/pandawa' => 
  array (
    'providers' => 
    array (
      0 => 'Pandawa\\Module\\Api\\PandawaApiModule',
      1 => 'Pandawa\\Module\\Event\\PandawaEventModule',
      2 => 'Pandawa\\Module\\Bus\\PandawaBusModule',
      3 => 'Pandawa\\Module\\Generator\\PandawaGeneratorModule',
      4 => 'Pandawa\\Module\\Rule\\PandawaRuleModule',
      5 => 'Pandawa\\Module\\Ddd\\PandawaDddModule',
      6 => 'Pandawa\\Module\\Resource\\PandawaResourceModule',
      7 => 'Pandawa\\Module\\Presenter\\PandawaPresenterModule',
      8 => 'Pandawa\\Module\\Reactive\\PandawaReactiveModule',
    ),
  ),
);