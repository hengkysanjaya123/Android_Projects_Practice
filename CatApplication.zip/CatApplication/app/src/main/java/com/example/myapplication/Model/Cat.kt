package com.example.myapplication.Model

import java.io.Serializable

data class Cat(val id : String, val url : String) : Serializable